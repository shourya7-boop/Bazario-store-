# Bazario demo store

A beginner-friendly, responsive storefront built with plain HTML, CSS and JavaScript.

## Preview on your computer
1. Unzip the folder.
2. Open `index.html` in a modern browser.

## Publish free with GitHub Pages
1. Create/sign in to GitHub.
2. Create a public repository named `bazario-store`.
3. Upload `index.html`, `style.css`, and `script.js` from this folder.
4. Open repository Settings → Pages.
5. Under Build and deployment, choose Deploy from a branch, select `main` and `/ (root)`, then Save.
6. Wait for GitHub Pages to publish the site. The URL will be shown in Settings → Pages.

## Important before using with real customers
- All products, prices and emoji illustrations are sample/demo content. Replace them with products you are actually allowed to sell, accurate descriptions, real photos and correct prices.
- This is a front-end demo only. It does not save orders to a server, send notifications, manage stock, or process payments.
- The order form only creates a message on the visitor's device. You must arrange a secure way to receive and fulfil real orders.
- Add clear contact details, shipping, returns/refunds, privacy and terms pages before launching.
- Do not collect card details yourself. Use a reputable payment provider and complete the required adult/business verification with a parent or guardian if you are under 18.
