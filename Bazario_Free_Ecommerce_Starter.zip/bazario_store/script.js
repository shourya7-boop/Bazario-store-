const products = [
  {id:1,name:"Everyday Wireless Headphones",category:"Electronics",price:899,emoji:"🎧"},
  {id:2,name:"Classic Cotton T-Shirt",category:"Fashion",price:499,emoji:"👕"},
  {id:3,name:"Insulated Water Bottle",category:"Home",price:349,emoji:"🧴"},
  {id:4,name:"Daily Skincare Set",category:"Beauty",price:699,emoji:"🧴"},
  {id:5,name:"Comfort Running Shoes",category:"Fashion",price:1299,emoji:"👟"},
  {id:6,name:"Desk Study Lamp",category:"Home",price:599,emoji:"💡"},
  {id:7,name:"Yoga Mat",category:"Sports",price:449,emoji:"🧘"},
  {id:8,name:"Notebook & Journal Set",category:"Books",price:249,emoji:"📚"}
];
let cart = [];
let activeCategory = "All";
let searchTerm = "";
const money = n => "₹" + n.toLocaleString("en-IN");

function renderProducts(){
  const filtered = products.filter(p => (activeCategory==="All" || p.category===activeCategory) && (p.name.toLowerCase().includes(searchTerm) || p.category.toLowerCase().includes(searchTerm)));
  document.getElementById("productGrid").innerHTML = filtered.map(p => `
    <article class="product-card">
      <div class="product-image">${p.emoji}</div>
      <div class="product-info"><span class="product-category">${p.category}</span><h3>${p.name}</h3>
        <div class="product-bottom"><span class="price">${money(p.price)}</span><button class="add-button" onclick="addToCart(${p.id})">＋ Add</button></div>
      </div>
    </article>`).join("");
  document.getElementById("resultCount").textContent = `${filtered.length} sample products`;
  document.getElementById("emptyState").hidden = filtered.length!==0;
}
function addToCart(id){const item=cart.find(x=>x.id===id);if(item)item.qty++;else cart.push({id,qty:1});renderCart();openCart();}
function changeQty(id,delta){const item=cart.find(x=>x.id===id);if(!item)return;item.qty+=delta;if(item.qty<=0)cart=cart.filter(x=>x.id!==id);renderCart();}
function renderCart(){
  const count=cart.reduce((s,x)=>s+x.qty,0), total=cart.reduce((s,x)=>s+x.qty*products.find(p=>p.id===x.id).price,0);
  document.getElementById("cartCount").textContent=count;document.getElementById("cartTotal").textContent=money(total);
  document.getElementById("cartItems").innerHTML=cart.length?cart.map(x=>{const p=products.find(y=>y.id===x.id);return `<div class="cart-line"><div class="cart-emoji">${p.emoji}</div><div class="cart-line-info"><strong>${p.name}</strong><small>${money(p.price)} each</small></div><div class="qty-controls"><button onclick="changeQty(${p.id},-1)" aria-label="Decrease quantity">−</button><span>${x.qty}</span><button onclick="changeQty(${p.id},1)" aria-label="Increase quantity">+</button></div></div>`}).join(""):'<p class="muted">Your cart is empty. Add a product to get started.</p>';
  document.getElementById("checkoutButton").disabled=!cart.length;
}
function openCart(){document.getElementById("cartDrawer").classList.add("open");document.getElementById("backdrop").classList.add("show");document.getElementById("cartDrawer").setAttribute("aria-hidden","false");}
function closeCart(){document.getElementById("cartDrawer").classList.remove("open");document.getElementById("backdrop").classList.remove("show");document.getElementById("cartDrawer").setAttribute("aria-hidden","true");}
document.getElementById("cartToggle").addEventListener("click",openCart);
document.getElementById("closeCart").addEventListener("click",closeCart);
document.getElementById("backdrop").addEventListener("click",closeCart);
document.getElementById("checkoutButton").addEventListener("click",()=>{closeCart();document.getElementById("orderResult").hidden=true;document.getElementById("orderForm").hidden=false;document.getElementById("checkoutDialog").showModal();});
document.querySelectorAll(".category").forEach(b=>b.addEventListener("click",()=>{document.querySelector(".category.active").classList.remove("active");b.classList.add("active");activeCategory=b.dataset.category;renderProducts();}));
document.getElementById("searchForm").addEventListener("submit",e=>{e.preventDefault();searchTerm=document.getElementById("searchInput").value.trim().toLowerCase();renderProducts();document.getElementById("products").scrollIntoView({behavior:"smooth"});});
document.getElementById("orderForm").addEventListener("submit",e=>{
  e.preventDefault();
  const data=new FormData(e.currentTarget);
  const lines=cart.map(x=>{const p=products.find(y=>y.id===x.id);return `${p.name} x ${x.qty} — ${money(p.price*x.qty)}`;});
  const total=cart.reduce((s,x)=>s+x.qty*products.find(p=>p.id===x.id).price,0);
  const message=`BAZARIO — ORDER ENQUIRY\nName: ${data.get("customerName")}\nPhone: ${data.get("phone")}\nAddress: ${data.get("address")}\n\nItems:\n${lines.join("\n")}\n\nSubtotal: ${money(total)}\n\nPlease confirm stock, delivery charges and payment options.`;
  document.getElementById("orderText").textContent=message;
  document.getElementById("orderForm").hidden=true;document.getElementById("orderResult").hidden=false;
});
document.getElementById("copyOrder").addEventListener("click",async()=>{const text=document.getElementById("orderText").textContent;try{await navigator.clipboard.writeText(text);document.getElementById("copyOrder").textContent="Copied!";}catch(e){document.getElementById("orderText").select?.();alert("Please select and copy the order message.");}});
renderProducts();renderCart();
